#### Preamble ####
# Purpose: Simulates... [...UPDATE THIS...]
# Author: Charlie Zhang
# Date: Sep 19th, 2024
# Contact: zqycharlie.zhang@mail.utoronto.ca
# License: MIT
# Pre-requisites: None
# Any other information needed? None


#### Workspace setup ####
library(tidyverse)
# [...UPDATE THIS...]

#### Load data ####
# [...ADD CODE HERE...]



